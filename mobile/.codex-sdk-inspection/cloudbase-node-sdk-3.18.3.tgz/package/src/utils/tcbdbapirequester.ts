import * as tcbapicaller from './tcbapirequester'
import { ICustomReqOpts, ICloudBaseDBConfig } from '../../types'

export class TcbDBApiHttpRequester {
  private readonly config: ICloudBaseDBConfig

  public constructor(config: ICloudBaseDBConfig) {
    this.config = config
  }

  /**
     * 发送请求
     *
     * @param dbParams   - 数据库请求参数
     * @param opts  - 可选配置项
     */
  public async send(api: string, data: any, opts?: ICustomReqOpts): Promise<any> {
    const { instance, database, ...config } = this.config
    const params = { ...data, action: api, instance, database }
    return await tcbapicaller.request({
      config,
      params,
      method: 'post',
      opts,
      headers: {
        'content-type': 'application/json'
      }
    })
  }
}
